/*
 * Copyright (c) Rakuten Payment, Inc. All Rights Reserved.
 *
 * This program is the information asset which are handled
 * as "Strictly Confidential".
 * Permission of use is only admitted in Rakuten Payment, Inc.
 * If you don't have permission, MUST not be published,
 * broadcast, rewritten for broadcast or publication
 * or redistributed directly or indirectly in any medium.
 */

import Combine
import Foundation

public protocol ___VARIABLE_productName___UseCase {}

public final class ___VARIABLE_productName___DefaultUseCase: ___VARIABLE_productName___UseCase {
    private var repository: ___VARIABLE_productName___Repository

    public init(repository: ___VARIABLE_productName___Repository) {
        self.repository = repository
    }
}
