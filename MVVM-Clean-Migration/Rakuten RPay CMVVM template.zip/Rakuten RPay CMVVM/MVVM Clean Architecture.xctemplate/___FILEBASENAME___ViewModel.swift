/*
 * Copyright (c) Rakuten Payment, Inc. All Rights Reserved.
 *
 * This program is the information asset which are handled
 * as "Strictly Confidential".
 * Permission of use is only admitted in Rakuten Payment, Inc.
 * If you don't have permission, MUST not be published,
 * broadcast, rewritten for broadcast or publication
 * or redistributed directly or indirectly in any medium.
 */

import Combine
import Foundation

public protocol ___VARIABLE_productName___ViewModelInput {}

public protocol ___VARIABLE_productName___ViewModelOutput {}

public protocol ___VARIABLE_productName___ViewModelManager {
    var input: ___VARIABLE_productName___ViewModelInput { get }
    var output: ___VARIABLE_productName___ViewModelOutput { get }
}

public class ___FILEBASENAME___: ___VARIABLE_productName___ViewModelInput, ___VARIABLE_productName___ViewModelOutput, ___VARIABLE_productName___ViewModelManager {
    private var subscription = Set<AnyCancellable>()
    private let useCase: ___VARIABLE_productName___UseCase

    public init(useCase: ___VARIABLE_productName___UseCase) {
        self.useCase = useCase
        self.initializeAction()
    }

    public var input: ___VARIABLE_productName___ViewModelInput {
        return self
    }

    public var output: ___VARIABLE_productName___ViewModelOutput {
        return self
    }

    /// input

    /// output
  
    /// store properties
}

extension ___FILEBASENAME___ {
    private func initializeAction() {
        //binding input and output
    }
}
