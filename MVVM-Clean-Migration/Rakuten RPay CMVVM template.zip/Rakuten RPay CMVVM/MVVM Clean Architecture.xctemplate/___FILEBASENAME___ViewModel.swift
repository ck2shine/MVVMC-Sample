/*
 * Copyright (c) Rakuten Payment, Inc. All Rights Reserved.
 *
 * This program is the information asset which are handled
 * as "Strictly Confidential".
 * Permission of use is only admitted in Rakuten Payment, Inc.
 * If you don't have permission, MUST not be published,
 * broadcast, rewritten for broadcast or publication
 * or redistributed directly or indirectly in any medium.
 */

import Combine
import Foundation

public class ___FILEBASENAME___ {
    private var subscription = Set<AnyCancellable>()
    private let useCase: ___VARIABLE_productName___UseCase

    public init(useCase: ___VARIABLE_productName___UseCase) {
        self.useCase = useCase
        self.initializeAction()
    }   

    /// input

    /// output
  
    /// store properties
}

extension ___FILEBASENAME___ {
    private func initializeAction() {
        //binding input and output
    }
}
